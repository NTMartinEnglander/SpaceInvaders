namespace SpaceInvaders
{
    public partial class Form1 : Form
    {
        int spaceshipSpeed = 7;
        string direction = "none";
        bool isFiring = false;
        int noOfProjectiles = 0;
        List <PictureBox> pictureBoxesLeft= new List<PictureBox>();
        List<PictureBox> pictureBoxesRight = new List<PictureBox>();
        int projectileLeftStartX = 0;
        int projectileLeftStartY = 0;
        int projectileRightStartX = 0;
        int projectileRightStartY = 0;
        Size projectileSize = new Size(19, 21);
        int projectileYDecrement = 27;
        int timeFiring = 0;
        Bitmap bulletBitmap = new Bitmap(Properties.Resources.goldbullet);

        public Form1()
        {
            InitializeComponent();

            this.KeyDown += Form1_KeyDown;
            this.KeyUp += Form1_KeyUp;

            //set initial location for picture boxes, from the location of the fighter
            projectileLeftStartX = pictureBoxSpaceship.Location.X + 9;
            projectileLeftStartY = pictureBoxSpaceship.Location.Y - 27;
            projectileRightStartX = pictureBoxSpaceship.Location.X + 46;
            projectileRightStartY = pictureBoxSpaceship.Location.Y - 27;

            //populate the lists of projectile pictureboxes
            for (int i = 0; i < 10  ; i++)
            {
                pictureBoxesLeft.Add(new PictureBox());
                pictureBoxesLeft[i].Location = new Point(projectileLeftStartX, projectileLeftStartY - (i * projectileYDecrement));
                pictureBoxesLeft[i].Size = projectileSize;
                pictureBoxesLeft[i].BackColor = Color.Transparent;
                pictureBoxesLeft[i].Image = this.bulletBitmap;
                pictureBoxesLeft[i].SizeMode = PictureBoxSizeMode.StretchImage;
                pictureBoxesLeft[i].Visible = false;
                this.Controls.Add(pictureBoxesLeft[i]);

                pictureBoxesRight.Add(new PictureBox());
                pictureBoxesRight[i].Location = new Point(projectileRightStartX, projectileRightStartY - (i * projectileYDecrement));
                pictureBoxesRight[i].Size = projectileSize;
                pictureBoxesRight[i].BackColor = Color.Transparent;
                pictureBoxesRight[i].Image = this.bulletBitmap;
                pictureBoxesRight[i].SizeMode = PictureBoxSizeMode.StretchImage;
                pictureBoxesRight[i].Visible = false;
                this.Controls.Add(pictureBoxesRight[i]);
            }
        }

        private void Form1_KeyUp(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                //stop spaceship animation timer
                this.timerFighter.Stop();

                //reset direction
                this.direction = "none";
            }
            else if (e.KeyCode == Keys.Right)
            {
                //stop spaceship animation timer
                this.timerFighter.Stop();

                //reset direction
                this.direction = "none";
            }
            else if (e.KeyCode == Keys.Space)
            {
                //stop firing and hide the projectile
                this.isFiring = false;
                this.timerProjectile.Stop();
            }
        }

        private void Form1_KeyDown(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                //set direction of spaceship animation
                this.direction = "left";

                //start animation timer
                this.timerFighter.Start();
            }
            else if (e.KeyCode == Keys.Right)
            {
                //set direction of spaceship animation
                this.direction = "right";

                //start animation timer
                this.timerFighter.Start();
            }
            else if (e.KeyCode == Keys.Space)
            {
                //set flag for firing, start projectile timer, show projectiles
                this.isFiring = true;
                this.timerProjectile.Start();
            }
        }


        //timer event handler
        private void timerSpaceShip_Tick(object sender, EventArgs e)
        {
            //move spaceship according to direction 

            //test which direction is chosen
            if (this.direction == "left")
            {
                //test if the spaceship will get out of bounds if moving to the left
                if(this.pictureBoxSpaceship.Location.X >= spaceshipSpeed)
                {
                    Point tempPoint = new Point(this.pictureBoxSpaceship.Location.X - spaceshipSpeed, this.pictureBoxSpaceship.Location.Y);
                    this.pictureBoxSpaceship.Location = tempPoint;
                }
            }
            else if (this.direction == "right")
            {
                //test if the spaceship will get out of bounds if moving to the right
                if (this.pictureBoxSpaceship.Location.X + this.pictureBoxSpaceship.Width < this.Width - 25)
                {
                    Point tempPoint = new Point(this.pictureBoxSpaceship.Location.X + spaceshipSpeed, this.pictureBoxSpaceship.Location.Y);
                    this.pictureBoxSpaceship.Location = tempPoint;
                }
            }

            //update coordinates for projectiles
            projectileLeftStartX = pictureBoxSpaceship.Location.X + 9;
            projectileLeftStartY = pictureBoxSpaceship.Location.Y - 27;
            projectileRightStartX = pictureBoxSpaceship.Location.X + 46;
            projectileRightStartY = pictureBoxSpaceship.Location.Y - 27;
        }

        private void timerProjectile_Tick(object sender, EventArgs e)
        {
            if (this.isFiring == true)
            {
                try
                {
                    this.pictureBoxesLeft[this.noOfProjectiles].Visible = true;
                    this.pictureBoxesLeft[this.noOfProjectiles].Location = new Point(pictureBoxSpaceship.Location.X + 9, pictureBoxSpaceship.Location.Y - (noOfProjectiles * projectileYDecrement));
                }
                catch (Exception ex)
                {

                }

                //increment no of projectiles to be seen
                if (this.noOfProjectiles < 10)
                {
                    this.noOfProjectiles++;
                }

                /*
                for (int i = 0; i < noOfProjectiles; i++)
                {
                    try
                    {
                        //make projectiles visible
                        this.pictureBoxesLeft[i].Visible = true;
                        this.pictureBoxesRight[i].Visible = true;

                        pictureBoxesLeft[i].Location = new Point(projectileLeftStartX, projectileLeftStartY - (i * projectileYDecrement));
                        this.pictureBoxesRight[i].Location = new Point(this.projectileRightStartX, projectileRightStartY - (i * projectileYDecrement));
                    }
                    catch (Exception ex)
                    {

                    }
                }*/
            }
        }

        private void timerHideBullets_Tick(object sender, EventArgs e)
        {

        }
    }
}